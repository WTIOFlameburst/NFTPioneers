package ca.yorku.nftpioneers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    int[] images = {R.drawable.bananapenguin,R.drawable.bandanacat,R.drawable.blingmonkey,R.drawable.convictmonkey,
            R.drawable.goldenmonkey,R.drawable.leopardmonkey,R.drawable.nyancat,R.drawable.samuraipenguin};
    String[] titleOfNFTs = {"Banana Penguin", "Bandana Cat", "Bling Monkey", "Convict Monkey", "Golden Monkey", "Leopard Monkey", "Nyan Cat", "Samurai Penguin"};
    String[] NFTRarity = {"Legendary", "Common", "Epic", "Common","Legendary", "Common","Legendary","Epic"};
    double[] NFTPrice = {1750,375,850,150,2000,475,1500,750};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        int min = 1;
        int max = 8;

        int random_int = (int) Math.floor(Math.random()*(max-min+1)+min);

        //first nft
        TextView firstNFTTitle = (TextView) findViewById(R.id.textView7);
        firstNFTTitle.setText(titleOfNFTs[random_int].toString());

        TextView aboutFirstNFT = (TextView) findViewById(R.id.textView16);
        aboutFirstNFT.setText(NFTRarity[random_int]);

        ImageView nftTOP = (ImageView) findViewById(R.id.imageButton13);
        nftTOP.setImageResource(images[random_int]);

        random_int=0;
        random_int = (int) Math.floor(Math.random()*(max-min+1)+min);

        //second nft
        TextView secondNFTTitle = (TextView) findViewById(R.id.textView18);
        secondNFTTitle.setText(titleOfNFTs[random_int]);

        TextView aboutSecondNFT = (TextView) findViewById(R.id.textView17);
        aboutSecondNFT.setText(NFTRarity[random_int]);

        ImageView nftTWO = (ImageView) findViewById(R.id.imageButton2);
        nftTWO.setImageResource(images[random_int]);

        random_int = 0;
        random_int = (int) Math.floor(Math.random()*(max-min+1)+min);

        //third nft
        TextView thirdNFTTitle = (TextView) findViewById(R.id.textView19);
        thirdNFTTitle.setText(titleOfNFTs[random_int]);

        TextView aboutThirdNFT = (TextView) findViewById(R.id.textView20);
        aboutThirdNFT.setText(NFTRarity[random_int]);

        ImageView nftTHREE = (ImageView) findViewById(R.id.imageButton12);
        nftTHREE.setImageResource(images[random_int]);

        random_int = 0;
        random_int = (int) Math.floor(Math.random()*(max-min+1)+min);

        //fourth NFT
        TextView fourthNFTTitle = (TextView) findViewById(R.id.textView21);
        fourthNFTTitle.setText(titleOfNFTs[random_int]);

        TextView aboutfourthNFT = (TextView) findViewById(R.id.textView22);
        aboutfourthNFT.setText(NFTRarity[random_int]);

        ImageView nftFOUR = (ImageView) findViewById(R.id.imageButton11);
        nftFOUR.setImageResource(images[random_int]);

        Button mainMenu3 = (Button) findViewById(R.id.main_menu_3);
        mainMenu3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                MainActivity2();
            }
        });
    }
    public void MainActivity2(){
        Intent intent = new Intent(this,MainActivity2.class);
        startActivity(intent);
    }
}

